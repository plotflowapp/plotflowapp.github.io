# Builds all targets and assembles dist\PrePlotCheck.bundle
# Usage:  .\build.ps1        (needs the .NET SDK 10 or newer; internet on the first run)
# The full build output is saved to build-log.txt next to this script. Send that file if something fails.
param([string]$Configuration = "Release")

# Output of the dotnet tool on stderr must not abort the script; exit codes are checked explicitly below.
$ErrorActionPreference = "Continue"

# Readable output: English messages, correct console encoding
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:DOTNET_CLI_UI_LANGUAGE = "en"
$env:VSLANG = "1033"

$root   = $PSScriptRoot
$bundle = Join-Path $root "dist\PrePlotCheck.bundle"
$log    = Join-Path $root "build-log.txt"

function Log([string]$text) {
    Write-Host $text
    Add-Content -Path $log -Value $text -Encoding UTF8
}

Set-Content -Path $log -Value ("Build started " + (Get-Date)) -Encoding UTF8

# The ribbon button needs AdWindows.dll from an installed AutoCAD.
# Default folders are checked; set $env:AcadDir2025 (etc.) before running to point to another location.
foreach ($year in 2024, 2025, 2026, 2027) {
    $override = [Environment]::GetEnvironmentVariable("AcadDir$year")
    $dir = if ($override) { $override } else { "C:\Program Files\Autodesk\AutoCAD $year" }
    if (-not (Test-Path "$dir\AdWindows.dll")) {
        Log "Note: AutoCAD $year not found at '$dir'. Builds that depend on it will have no ribbon button (the command still works)."
    }
}

if (Test-Path $bundle) { Remove-Item $bundle -Recurse -Force }

$targets = @(
    @{ Framework = "net48";           Folder = "net48"  },   # AutoCAD 2024
    @{ Framework = "net8.0-windows";  Folder = "net8"   },   # AutoCAD 2025, 2026
    @{ Framework = "net10.0-windows"; Folder = "net10"  }    # AutoCAD 2027
)

$failed = $false
foreach ($t in $targets) {
    Log ">>> Building $($t.Framework)"
    dotnet publish "$root\PrePlotCheck.csproj" -c $Configuration -f $t.Framework -o "$bundle\Contents\$($t.Folder)" 2>&1 |
        ForEach-Object { Log ($_.ToString()) }
    if ($LASTEXITCODE -ne 0) {
        Log "!!! $($t.Framework) build failed (exit code $LASTEXITCODE)"
        $failed = $true
        break
    }
}

if ($failed) {
    Write-Host ""
    Write-Host "BUILD FAILED. Please send me this file: $log"
    exit 1
}

Copy-Item "$root\bundle\PackageContents.xml" $bundle
Log "Bundle ready: $bundle"
Log "Copy it to %APPDATA%\Autodesk\ApplicationPlugins\ and restart AutoCAD."
