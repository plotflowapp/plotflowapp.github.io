using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    /// <summary>Attached raster images and PDF underlays.</summary>
    internal class ExternalFilesCheck : ICheck
    {
        public string Name { get { return "Images & underlays"; } }

        public void Run(Database db, Transaction tr, List<Issue> issues)
        {
            CheckImages(db, tr, issues);
            CheckPdfUnderlays(db, tr, issues);
        }

        private void CheckImages(Database db, Transaction tr, List<Issue> issues)
        {
            ObjectId dictId = RasterImageDef.GetImageDictionary(db);
            if (dictId.IsNull) return;

            var dict = (DBDictionary)tr.GetObject(dictId, OpenMode.ForRead);
            foreach (DBDictionaryEntry entry in dict)
            {
                var def = tr.GetObject(entry.Value, OpenMode.ForRead) as RasterImageDef;
                if (def == null) continue;

                string file = string.IsNullOrEmpty(def.ActiveFileName) ? def.SourceFileName : def.ActiveFileName;
                if (!FileResolver.Exists(db, file, FindFileHint.Default))
                {
                    issues.Add(new Issue(Severity.Error, Name, null,
                        string.Format("Image '{0}' not found: {1}", entry.Key, def.SourceFileName)));
                }
            }
        }

        private void CheckPdfUnderlays(Database db, Transaction tr, List<Issue> issues)
        {
            const string key = "ACAD_PDFDEFINITIONS";

            var nod = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId, OpenMode.ForRead);
            if (!nod.Contains(key)) return;

            var dict = (DBDictionary)tr.GetObject(nod.GetAt(key), OpenMode.ForRead);
            foreach (DBDictionaryEntry entry in dict)
            {
                var def = tr.GetObject(entry.Value, OpenMode.ForRead) as UnderlayDefinition;
                if (def == null) continue;

                string file = string.IsNullOrEmpty(def.ActiveFileName) ? def.SourceFileName : def.ActiveFileName;
                if (!FileResolver.Exists(db, file, FindFileHint.Default))
                {
                    issues.Add(new Issue(Severity.Error, Name, null,
                        string.Format("PDF underlay '{0}' not found: {1}", entry.Key, def.SourceFileName)));
                }
            }
        }
    }
}
