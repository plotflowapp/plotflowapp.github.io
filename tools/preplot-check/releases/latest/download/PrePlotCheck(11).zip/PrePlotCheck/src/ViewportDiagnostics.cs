using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Checks;

namespace PrePlotCheck
{
    /// <summary>Dumps raw viewport data per layout, to understand how real drawings are structured.</summary>
    internal static class ViewportDiagnostics
    {
        public static string Run(Document doc)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Pre-Plot Check diagnostics");
            sb.AppendLine("Drawing: " + System.IO.Path.GetFileName(doc.Name));
            sb.AppendLine("Current layout: " + LayoutManager.Current.CurrentLayout);
            sb.AppendLine();

            Database db = doc.Database;
            using (doc.LockDocument())
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (Layout layout in LayoutHelper.GetPaperLayouts(db, tr))
                {
                    var btr = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForRead);
                    int others = 0;

                    sb.AppendLine(string.Format("Layout '{0}' (tab {1})", layout.LayoutName, layout.TabOrder));

                    foreach (ObjectId id in btr)
                    {
                        if (id.ObjectClass.DxfName != "VIEWPORT")
                        {
                            others++;
                            continue;
                        }

                        var vp = (Viewport)tr.GetObject(id, OpenMode.ForRead);
                        sb.AppendLine(string.Format(
                            "  viewport handle={0} number={1} on={2} visible={3} size={4:0.##}x{5:0.##} scale={6:0.####} locked={7} layer={8}",
                            id.Handle, vp.Number, vp.On, vp.Visible, vp.Width, vp.Height, vp.CustomScale, vp.Locked, vp.Layer));
                    }

                    sb.AppendLine("  other entities on the layout: " + others);
                }
                tr.Commit();
            }

            return sb.ToString();
        }
    }
}
