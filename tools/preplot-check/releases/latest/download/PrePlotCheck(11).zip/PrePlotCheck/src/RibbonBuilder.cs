#if RIBBON
using System;
using System.IO;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Autodesk.Windows;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace PrePlotCheck
{
    /// <summary>Adds a "Toritex" ribbon tab with a Pre-Plot Check button.</summary>
    internal static class RibbonBuilder
    {
        private const string TabId = "TORITEX_RIBBON_TAB";
        private const string TabTitle = "Toritex";
        private const string PanelId = "TORITEX_PREPLOTCHECK_PANEL";

        public static void Create()
        {
            if (ComponentManager.Ribbon != null)
                BuildWhenIdle();
            else
                ComponentManager.ItemInitialized += OnItemInitialized;
        }

        private static void OnItemInitialized(object sender, RibbonItemEventArgs e)
        {
            // The ribbon may not exist yet when the plugin loads at startup.
            if (ComponentManager.Ribbon == null) return;

            ComponentManager.ItemInitialized -= OnItemInitialized;
            BuildWhenIdle();
        }

        /// <summary>
        /// Waits for the first idle moment so that other Toritex plugins loaded at startup
        /// have already created their ribbon tab; we then add our panel to that tab.
        /// </summary>
        private static void BuildWhenIdle()
        {
            AcApp.Idle += OnIdle;
        }

        private static void OnIdle(object sender, EventArgs e)
        {
            AcApp.Idle -= OnIdle;
            try { Build(); }
            catch { /* no ribbon button; the command still works */ }
        }

        private static void Build()
        {
            RibbonControl ribbon = ComponentManager.Ribbon;

            RibbonTab tab = ribbon.FindTab(TabId);
            if (tab == null)
            {
                foreach (RibbonTab candidate in ribbon.Tabs)
                {
                    if (string.Equals(candidate.Title, TabTitle, StringComparison.OrdinalIgnoreCase))
                    {
                        tab = candidate;   // the tab of another Toritex plugin: share it
                        break;
                    }
                }
            }

            if (tab == null)
            {
                tab = new RibbonTab();
                tab.Title = TabTitle;
                tab.Id = TabId;
                ribbon.Tabs.Add(tab);
            }

            foreach (RibbonPanel existing in tab.Panels)
            {
                if (existing.Source != null && existing.Source.Id == PanelId) return; // already there
            }

            var source = new RibbonPanelSource();
            source.Title = "Drawing Checks";
            source.Id = PanelId;

            var button = new RibbonButton();
            button.Id = "TORITEX_PREPLOTCHECK_BUTTON";
            button.Text = "Pre-Plot\nCheck";
            button.ShowText = true;
            button.ShowImage = true;
            button.Size = RibbonItemSize.Large;
            button.Orientation = System.Windows.Controls.Orientation.Vertical;
            button.LargeImage = LoadIcon("icon32.png");
            button.Image = LoadIcon("icon16.png");
            button.ToolTip = "Check the drawing for problems before plotting to PDF";
            button.CommandParameter = "PREPLOTCHECK ";
            button.CommandHandler = new RunCommandHandler();

            source.Items.Add(button);

            var panel = new RibbonPanel();
            panel.Source = source;
            tab.Panels.Add(panel);
        }

        private static BitmapImage LoadIcon(string resourceName)
        {
            try
            {
                using (Stream stream = typeof(RibbonBuilder).Assembly.GetManifestResourceStream(resourceName))
                {
                    if (stream == null) return null;

                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = stream;
                    bitmap.EndInit();
                    bitmap.Freeze();
                    return bitmap;
                }
            }
            catch
            {
                return null; // the button still works without an icon
            }
        }

        private class RunCommandHandler : ICommand
        {
            public event EventHandler CanExecuteChanged { add { } remove { } }

            public bool CanExecute(object parameter) { return true; }

            public void Execute(object parameter)
            {
                var item = parameter as RibbonButton;
                if (item == null) return;

                var doc = AcApp.DocumentManager.MdiActiveDocument;
                if (doc != null)
                    doc.SendStringToExecute(item.CommandParameter as string, true, false, true);
            }
        }
    }
}
#endif
