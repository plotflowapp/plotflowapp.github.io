namespace PrePlotCheck.Model
{
    public enum Severity
    {
        Error = 0,
        Warning = 1,
        Info = 2
    }

    public class Issue
    {
        public Issue(Severity severity, string category, string layout, string message)
        {
            Severity = severity;
            Category = category;
            Layout = layout;
            Message = message;
        }

        public Severity Severity { get; private set; }
        public string Category { get; private set; }

        /// <summary>Layout name the issue belongs to, or null for drawing-wide issues.</summary>
        public string Layout { get; private set; }

        public string Message { get; private set; }
    }
}
