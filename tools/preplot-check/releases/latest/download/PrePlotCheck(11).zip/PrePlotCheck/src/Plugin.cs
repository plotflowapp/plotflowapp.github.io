using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Runtime;

[assembly: ExtensionApplication(typeof(PrePlotCheck.Plugin))]
[assembly: CommandClass(typeof(PrePlotCheck.Commands))]

namespace PrePlotCheck
{
    public class Plugin : IExtensionApplication
    {
        public void Initialize()
        {
#if RIBBON
            try { RibbonBuilder.Create(); }
            catch { /* no ribbon button; the command still works */ }
#endif
            Document doc = Application.DocumentManager.MdiActiveDocument;
            if (doc != null)
                doc.Editor.WriteMessage("\nPre-Plot Check loaded. Use the Toritex ribbon tab or type PREPLOTCHECK.");
        }

        public void Terminate()
        {
        }
    }
}
