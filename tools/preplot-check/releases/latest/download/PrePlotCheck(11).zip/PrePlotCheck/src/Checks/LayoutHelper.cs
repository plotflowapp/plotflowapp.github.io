using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;

namespace PrePlotCheck.Checks
{
    internal static class LayoutHelper
    {
        /// <summary>Paper space layouts (Model excluded) in tab order.</summary>
        public static List<Layout> GetPaperLayouts(Database db, Transaction tr)
        {
            var list = new List<Layout>();
            var dict = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
            foreach (DBDictionaryEntry entry in dict)
            {
                var layout = (Layout)tr.GetObject(entry.Value, OpenMode.ForRead);
                if (!layout.ModelType) list.Add(layout);
            }
            list.Sort((a, b) => a.TabOrder.CompareTo(b.TabOrder));
            return list;
        }
    }
}
