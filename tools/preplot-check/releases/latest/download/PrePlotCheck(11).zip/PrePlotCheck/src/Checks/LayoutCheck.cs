using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    /// <summary>
    /// Finds layouts that have no real viewports.
    ///
    /// Findings from real drawings (see PREPLOTDIAG):
    ///  - Every layout contains the "overall" paper space viewport, which must not be counted as a real one.
    ///    In layouts that were not activated in this session Viewport.Number is -1, so it can't be used to find it;
    ///    the overall viewport is then the first viewport of the layout.
    ///  - Viewport.On is NOT reliable for layouts that were not activated in this session: it reads False even
    ///    though the viewport displays and plots fine. So the "viewport is off" check is deliberately not done here.
    ///    (A future "deep check" could activate each layout first.)
    /// </summary>
    internal class LayoutCheck : ICheck
    {
        public string Name { get { return "Layouts"; } }

        public void Run(Database db, Transaction tr, List<Issue> issues)
        {
            List<Layout> layouts = LayoutHelper.GetPaperLayouts(db, tr);

            if (layouts.Count == 0)
            {
                issues.Add(new Issue(Severity.Info, Name, null, "The drawing has no paper space layouts."));
                return;
            }

            foreach (Layout layout in layouts)
            {
                var btr = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForRead);

                int viewports = 0;
                int others = 0;

                foreach (ObjectId id in btr)
                {
                    if (id.ObjectClass.DxfName != "VIEWPORT")
                    {
                        others++;
                        continue;
                    }

                    viewports++;
                }

                // One of the viewports is always the overall paper space viewport.
                int realViewports = viewports > 0 ? viewports - 1 : 0;

                if (realViewports == 0)
                {
                    issues.Add(new Issue(Severity.Info, Name, layout.LayoutName,
                        others == 0
                            ? "Layout is empty."
                            : "Layout has no viewports. It prints only what is drawn directly in paper space (frame, title block, images)."));
                }
            }
        }
    }
}
