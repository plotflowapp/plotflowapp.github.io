using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    /// <summary>
    /// Looks at block attributes placed directly on each layout (the usual title block):
    /// placeholder values, empty sheet number/title, duplicate sheet numbers.
    /// v0.1 recognises a fixed list of common tag names; configurable tags come later.
    /// </summary>
    internal class TitleBlockCheck : ICheck
    {
        public string Name { get { return "Title block"; } }

        // Tags are normalised (upper case, no spaces/underscores/dashes) before comparing.
        private static readonly string[] NumberTags =
            { "SHEETNUMBER", "SHEETNO", "SHEETNUM", "DWGNO", "DRAWINGNUMBER", "DRAWINGNO", "SHEET", "NUMBER" };

        private static readonly string[] TitleTags =
            { "SHEETTITLE", "TITLE", "DRAWINGTITLE", "SHEETNAME", "DWGTITLE" };

        private static readonly Regex Placeholder =
            new Regex(@"^\W*(TBD|TBC|TODO|XXX+|\?{2,})\W*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static string Normalize(string tag)
        {
            return Regex.Replace((tag ?? string.Empty).ToUpperInvariant(), @"[\s_\-]", string.Empty);
        }

        public void Run(Database db, Transaction tr, List<Issue> issues)
        {
            var numbers = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            var layoutsWithoutNumber = new List<string>();
            bool anyNumberTag = false;

            foreach (Layout layout in LayoutHelper.GetPaperLayouts(db, tr))
            {
                var btr = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForRead);
                bool numberFound = false;

                foreach (ObjectId id in btr)
                {
                    if (id.ObjectClass.DxfName != "INSERT") continue;

                    var block = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (block == null) continue;

                    foreach (ObjectId attId in block.AttributeCollection)
                    {
                        var att = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                        if (att == null) continue;

                        string tag = Normalize(att.Tag);
                        string value = (att.TextString ?? string.Empty).Trim();

                        if (value.Length > 0 && Placeholder.IsMatch(value))
                        {
                            issues.Add(new Issue(Severity.Warning, Name, layout.LayoutName,
                                string.Format("Attribute {0} contains a placeholder value '{1}'.", att.Tag, value)));
                        }

                        if (Array.IndexOf(NumberTags, tag) >= 0)
                        {
                            anyNumberTag = true;
                            numberFound = true;

                            if (value.Length == 0)
                            {
                                issues.Add(new Issue(Severity.Warning, Name, layout.LayoutName,
                                    "Sheet number is empty."));
                            }
                            else
                            {
                                List<string> list;
                                if (!numbers.TryGetValue(value, out list))
                                {
                                    list = new List<string>();
                                    numbers[value] = list;
                                }
                                list.Add(layout.LayoutName);
                            }
                        }
                        else if (Array.IndexOf(TitleTags, tag) >= 0 && value.Length == 0)
                        {
                            issues.Add(new Issue(Severity.Warning, Name, layout.LayoutName,
                                "Sheet title is empty."));
                        }
                    }
                }

                if (!numberFound) layoutsWithoutNumber.Add(layout.LayoutName);
            }

            foreach (KeyValuePair<string, List<string>> pair in numbers.Where(p => p.Value.Count > 1))
            {
                string all = string.Join(", ", pair.Value);
                foreach (string layoutName in pair.Value)
                {
                    issues.Add(new Issue(Severity.Error, Name, layoutName,
                        string.Format("Sheet number '{0}' is used on several layouts: {1}.", pair.Key, all)));
                }
            }

            if (!anyNumberTag)
            {
                if (layoutsWithoutNumber.Count > 0)
                {
                    issues.Add(new Issue(Severity.Info, Name, null,
                        "No sheet number attribute recognised (looked for tags like SHEET_NUMBER, SHEETNO, DWG_NO). Duplicate-number check skipped."));
                }
            }
            else
            {
                foreach (string layoutName in layoutsWithoutNumber)
                {
                    issues.Add(new Issue(Severity.Warning, Name, layoutName,
                        "No sheet number attribute found on this layout."));
                }
            }
        }
    }
}
