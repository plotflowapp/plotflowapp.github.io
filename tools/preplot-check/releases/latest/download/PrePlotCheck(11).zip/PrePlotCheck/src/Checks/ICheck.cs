using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    /// <summary>One independent, read-only check. Must never modify the drawing.</summary>
    public interface ICheck
    {
        string Name { get; }
        void Run(Database db, Transaction tr, List<Issue> issues);
    }
}
