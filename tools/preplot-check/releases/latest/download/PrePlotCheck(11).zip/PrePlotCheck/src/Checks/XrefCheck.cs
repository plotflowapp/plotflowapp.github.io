using System.Collections.Generic;
using System.IO;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    internal class XrefCheck : ICheck
    {
        public string Name { get { return "Xrefs"; } }

        public void Run(Database db, Transaction tr, List<Issue> issues)
        {
            XrefGraph graph = db.GetHostDwgXrefGraph(false);

            // Node 0 is the host drawing itself.
            for (int i = 1; i < graph.NumNodes; i++)
            {
                XrefGraphNode node = graph.GetXrefNode(i);

                string path = string.Empty;
                try
                {
                    var btr = (BlockTableRecord)tr.GetObject(node.BlockTableRecordId, OpenMode.ForRead);
                    path = btr.PathName;
                }
                catch { /* path is informational only */ }

                switch (node.XrefStatus)
                {
                    case XrefStatus.FileNotFound:
                    case XrefStatus.Unresolved:
                        issues.Add(new Issue(Severity.Error, Name, null,
                            string.Format("Xref '{0}' not found: {1}", node.Name, path)));
                        break;

                    case XrefStatus.Unloaded:
                        issues.Add(new Issue(Severity.Warning, Name, null,
                            string.Format("Xref '{0}' is unloaded and will not appear in the PDF: {1}", node.Name, path)));
                        break;

                    case XrefStatus.Resolved:
                        if (IsAbsolute(path))
                            issues.Add(new Issue(Severity.Info, Name, null,
                                string.Format("Xref '{0}' uses an absolute path and will break on another machine: {1}", node.Name, path)));
                        break;
                }
            }
        }

        private static bool IsAbsolute(string path)
        {
            try { return !string.IsNullOrEmpty(path) && Path.IsPathRooted(path); }
            catch { return false; }
        }
    }
}
