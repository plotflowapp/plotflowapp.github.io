using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Runtime;
using PrePlotCheck.Checks;
using PrePlotCheck.Model;
using PrePlotCheck.UI;

namespace PrePlotCheck
{
    public class Commands
    {
        [CommandMethod("PREPLOTCHECK")]
        public void RunPrePlotCheck()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            if (doc == null) return;

            List<Issue> issues = CheckRunner.Run(doc);

            int errors = issues.Count(i => i.Severity == Severity.Error);
            int warnings = issues.Count(i => i.Severity == Severity.Warning);
            doc.Editor.WriteMessage(
                "\nPre-Plot Check: {0} error(s), {1} warning(s), {2} info.",
                errors, warnings, issues.Count - errors - warnings);

            ReportForm.ShowReport(doc, issues);
        }

        /// <summary>Support command: saves raw viewport data to a text file and opens it.</summary>
        [CommandMethod("PREPLOTDIAG")]
        public void RunDiagnostics()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            if (doc == null) return;

            string text = ViewportDiagnostics.Run(doc);
            string path = Path.Combine(Path.GetTempPath(), "PrePlotCheck_diag.txt");
            File.WriteAllText(path, text, new UTF8Encoding(false));

            doc.Editor.WriteMessage("\nDiagnostics saved: " + path);
            try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
            catch { /* the path is printed above */ }
        }
    }
}
