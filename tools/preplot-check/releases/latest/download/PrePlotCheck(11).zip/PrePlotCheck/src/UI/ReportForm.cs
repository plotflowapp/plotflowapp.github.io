using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Checks;
using PrePlotCheck.Model;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace PrePlotCheck.UI
{
    internal class ReportForm : Form
    {

        private static ReportForm _instance;

        private readonly DataGridView _grid = new DataGridView();
        private readonly Label _summary = new Label();
        private Document _doc;
        private List<Issue> _issues = new List<Issue>();

        public static void ShowReport(Document doc, List<Issue> issues)
        {
            if (_instance == null || _instance.IsDisposed)
            {
                _instance = new ReportForm();
                _instance.Bind(doc, issues);
                AcApp.ShowModelessDialog(_instance);
            }
            else
            {
                _instance.Bind(doc, issues);
                _instance.Activate();
            }
        }

        private ReportForm()
        {
            Text = "Pre-Plot Check";
            Width = 920;
            Height = 520;
            MinimumSize = new Size(640, 320);
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = false;

            _summary.Dock = DockStyle.Top;
            _summary.Height = 36;
            _summary.Padding = new Padding(8, 8, 8, 0);
            _summary.Font = new System.Drawing.Font(this.Font, System.Drawing.FontStyle.Bold);

            _grid.Dock = DockStyle.Fill;
            _grid.ReadOnly = true;
            _grid.AllowUserToAddRows = false;
            _grid.AllowUserToDeleteRows = false;
            _grid.RowHeadersVisible = false;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.MultiSelect = false;
            _grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            _grid.ColumnHeadersHeight = 34;
            _grid.BackgroundColor = SystemColors.Window;
            _grid.Columns.Add("Severity", "Severity");
            _grid.Columns.Add("Category", "Check");
            _grid.Columns.Add("Layout", "Layout");
            _grid.Columns.Add("Message", "Message");
            _grid.Columns[0].Width = 70;
            _grid.Columns[1].Width = 120;
            _grid.Columns[2].Width = 130;
            _grid.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _grid.CellDoubleClick += delegate { GoToSelectedLayout(); };

            var buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Bottom;
            buttons.Height = 40;
            buttons.Padding = new Padding(6, 6, 6, 0);

            buttons.Controls.Add(MakeButton("Re-run", delegate { Rerun(); }));
            buttons.Controls.Add(MakeButton("Go to layout", delegate { GoToSelectedLayout(); }));
            buttons.Controls.Add(MakeButton("Export CSV", delegate { ExportCsv(); }));


            Controls.Add(_summary);
            Controls.Add(buttons);
            Controls.Add(_grid);
            _grid.BringToFront();
        }

        private static Button MakeButton(string text, EventHandler onClick)
        {
            var b = new Button();
            b.Text = text;
            b.AutoSize = true;
            b.Click += onClick;
            return b;
        }

        private void Bind(Document doc, List<Issue> issues)
        {
            _doc = doc;
            _issues = issues;

            int errors = issues.Count(i => i.Severity == Severity.Error);
            int warnings = issues.Count(i => i.Severity == Severity.Warning);
            int infos = issues.Count - errors - warnings;

            string name = Path.GetFileName(doc.Name);
            _summary.Text = (errors + warnings == 0)
                ? string.Format("{0}: no problems found. Ready to plot.", name)
                : string.Format("{0}: {1} error(s), {2} warning(s), {3} info", name, errors, warnings, infos);

            _grid.Rows.Clear();
            foreach (Issue issue in issues)
            {
                int index = _grid.Rows.Add(issue.Severity.ToString(), issue.Category, issue.Layout ?? "-", issue.Message);
                DataGridViewRow row = _grid.Rows[index];
                row.Tag = issue;
                if (issue.Severity == Severity.Error) row.DefaultCellStyle.BackColor = Color.MistyRose;
                else if (issue.Severity == Severity.Warning) row.DefaultCellStyle.BackColor = Color.LemonChiffon;
            }
        }

        private void Rerun()
        {
            Document active = AcApp.DocumentManager.MdiActiveDocument;
            if (active == null) return;
            Bind(active, CheckRunner.Run(active));
        }

        private void GoToSelectedLayout()
        {
            if (_grid.CurrentRow == null) return;
            var issue = _grid.CurrentRow.Tag as Issue;
            if (issue == null || string.IsNullOrEmpty(issue.Layout)) return;

            if (AcApp.DocumentManager.MdiActiveDocument != _doc)
            {
                MessageBox.Show(this, "Switch back to the checked drawing first, or press Re-run.", "Pre-Plot Check");
                return;
            }

            try
            {
                using (_doc.LockDocument())
                {
                    LayoutManager.Current.CurrentLayout = issue.Layout;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Pre-Plot Check");
            }
        }

        private void ExportCsv()
        {
            using (var dialog = new SaveFileDialog())
            {
                dialog.Filter = "CSV (*.csv)|*.csv";
                dialog.FileName = "PrePlotCheck_" + Path.GetFileNameWithoutExtension(_doc.Name) + ".csv";
                if (dialog.ShowDialog(this) != DialogResult.OK) return;

                var sb = new StringBuilder();
                sb.AppendLine("Severity,Check,Layout,Message");
                foreach (Issue i in _issues)
                {
                    sb.AppendLine(string.Join(",", new[]
                    {
                        Csv(i.Severity.ToString()), Csv(i.Category), Csv(i.Layout ?? string.Empty), Csv(i.Message)
                    }));
                }

                try
                {
                    File.WriteAllText(dialog.FileName, sb.ToString(), new UTF8Encoding(true));
                    ShowInFolder(dialog.FileName);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(this, "Could not save the file:\n" + ex.Message + "\n\nTry another folder.", "Pre-Plot Check");
                }
            }
        }

        /// <summary>Opens Explorer with the saved file selected.</summary>
        private static void ShowInFolder(string path)
        {
            try
            {
                Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + path + "\"") { UseShellExecute = true });
            }
            catch { /* the file is saved; opening the folder is only a convenience */ }
        }

        private static string Csv(string value)
        {
            return "\"" + (value ?? string.Empty).Replace("\"", "\"\"") + "\"";
        }
    }
}
