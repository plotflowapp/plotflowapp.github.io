using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    public static class CheckRunner
    {
        private static readonly ICheck[] Checks =
        {
            new XrefCheck(),
            new ExternalFilesCheck(),
            new FontCheck(),
            new LayoutCheck(),
            new TitleBlockCheck()
        };

        public static List<Issue> Run(Document doc)
        {
            var issues = new List<Issue>();
            var layoutOrder = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            Database db = doc.Database;

            using (doc.LockDocument())
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (ICheck check in Checks)
                {
                    try
                    {
                        check.Run(db, tr, issues);
                    }
                    catch (System.Exception ex)
                    {
                        // One broken check must never kill the whole report.
                        issues.Add(new Issue(Severity.Info, check.Name, null,
                            "Check could not be completed: " + ex.Message));
                    }
                }

                // Remember the layout tab order so the report follows the drawing.
                int index = 0;
                foreach (Layout layout in LayoutHelper.GetPaperLayouts(db, tr))
                    layoutOrder[layout.LayoutName] = index++;

                tr.Commit();
            }

            return issues
                .OrderBy(i => i.Severity)
                .ThenBy(i => (i.Layout != null && layoutOrder.ContainsKey(i.Layout)) ? layoutOrder[i.Layout] : -1)
                .ToList();
        }
    }
}
