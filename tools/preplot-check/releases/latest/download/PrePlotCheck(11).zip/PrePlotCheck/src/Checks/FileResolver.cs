using System.IO;
using Autodesk.AutoCAD.DatabaseServices;

namespace PrePlotCheck.Checks
{
    internal static class FileResolver
    {
        /// <summary>True if the file exists next to the drawing, at its full path, or on AutoCAD's search paths.</summary>
        public static bool Exists(Database db, string file, FindFileHint hint)
        {
            if (string.IsNullOrWhiteSpace(file)) return false;

            try
            {
                string full = file;
                if (!Path.IsPathRooted(full) && !string.IsNullOrEmpty(db.Filename))
                {
                    string dir = Path.GetDirectoryName(db.Filename);
                    if (!string.IsNullOrEmpty(dir)) full = Path.Combine(dir, file);
                }
                if (File.Exists(full)) return true;
            }
            catch { /* invalid path characters etc. - fall through to FindFile */ }

            try
            {
                string found = HostApplicationServices.Current.FindFile(file, db, hint);
                return !string.IsNullOrEmpty(found);
            }
            catch
            {
                return false;
            }
        }
    }
}
