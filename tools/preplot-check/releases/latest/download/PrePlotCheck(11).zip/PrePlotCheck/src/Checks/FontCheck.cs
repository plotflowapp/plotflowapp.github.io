using System;
using System.Collections.Generic;
using System.Drawing.Text;
using Autodesk.AutoCAD.DatabaseServices;
using PrePlotCheck.Model;

namespace PrePlotCheck.Checks
{
    internal class FontCheck : ICheck
    {
        public string Name { get { return "Fonts"; } }

        public void Run(Database db, Transaction tr, List<Issue> issues)
        {
            var installed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var fonts = new InstalledFontCollection())
            {
                foreach (var family in fonts.Families) installed.Add(family.Name);
            }

            var table = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            foreach (ObjectId id in table)
            {
                var style = (TextStyleTableRecord)tr.GetObject(id, OpenMode.ForRead);
                if (style.IsShapeFile || string.IsNullOrEmpty(style.Name)) continue;

                string face = style.Font.TypeFace;
                string file = style.FileName;
                bool found;
                string fontLabel;

                if (!string.IsNullOrEmpty(face))
                {
                    // TrueType font: must be installed in Windows.
                    found = installed.Contains(face);
                    fontLabel = face;
                }
                else if (!string.IsNullOrEmpty(file))
                {
                    // SHX font: must be on AutoCAD's support path.
                    found = FileResolver.Exists(db, file, FindFileHint.FontFile);
                    fontLabel = file;
                }
                else
                {
                    continue;
                }

                if (!found)
                {
                    issues.Add(new Issue(Severity.Warning, Name, null,
                        string.Format("Text style '{0}' uses font '{1}' which is not available; text will be substituted in the PDF.",
                            style.Name, fontLabel)));
                }
            }
        }
    }
}
